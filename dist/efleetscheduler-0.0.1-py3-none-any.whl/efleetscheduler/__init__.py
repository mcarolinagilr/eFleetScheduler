"""
eFleetScheduler - Electric Fleet Scheduling Tool
"""

__version__ = "0.0.1"
__author__ = "Carolina Gil Ribeiro"

# Import main modules
from . import schedule_module